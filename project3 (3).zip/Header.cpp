//
// Created by jared on 10/25/2021.
//

#include "Header.h"

int Header::returnSize(){
    int size = attributes.size();
    return size;
}