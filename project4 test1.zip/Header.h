//
// Created by jared on 10/25/2021.
//

#ifndef PROJECT1_HEADER_H
#define PROJECT1_HEADER_H
#include "vector"
#include <string>

class Header {
public:
    std::vector<std::string> attributes;
    int returnSize();

    int find(std::string findMe);
};


#endif //PROJECT1_HEADER_H
