//
// Created by jared on 9/28/2021.
//

#include "Parameter.h"

void Parameter::toString() {
    std::cout << p;
}