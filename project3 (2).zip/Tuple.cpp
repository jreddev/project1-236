//
// Created by jared on 10/25/2021.
//

#include "Tuple.h"

int Tuple::returnSize(){
    int size = values.size();
    return size;
}
