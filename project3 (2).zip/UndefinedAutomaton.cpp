#include "UndefinedAutomaton.h"

void UndefinedAutomaton::S0(const std::string& input) {
        Serr();
}