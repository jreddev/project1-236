//
// Created by jared on 9/28/2021.
//

#ifndef PROJECT1_PARAMETER_H
#define PROJECT1_PARAMETER_H
#include <string>
#include <vector>
#include "fstream"
#include "iostream"

class Parameter {
private:
public:
    bool isConstant;
    std::string p;
    void toString();
};
// Have something to indicate whether this is an ID or STRING.

#endif //PROJECT1_PARAMETER_H
